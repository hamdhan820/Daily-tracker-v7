# Daily Routine Tracker 3.2.0 — Premium Editorial Flow

A mobile-first daily planner and study timetable built with JavaScript, CSS and Capacitor. This release refreshes the visual system while retaining the existing planner features and local data format.

## Android build
1. Upload this ZIP to the repository root.
2. Delete the old 3.1 ZIP from the repository root so the workflow cannot select it.
3. Keep the existing `.github/workflows/done.yml` workflow unchanged.
4. Open GitHub Actions and run **Build Daily Routine Tracker APK**.
5. Download the `Daily-Routine-Tracker-APK` artifact and install the APK.

The supplied repository workflow builds an Android debug APK. Android requires user approval to install it; this is not a signed Play Store release.

## What's new in 3.2
- Premium Editorial Flow visual system: continuous layouts, flat activity rows and no raised feature cards.
- Graphite Editorial is the first-launch theme.
- Reworked semantic colour tokens for Graphite, Ocean, Glass, Aurora, Royal, Sunset, Dark and Light themes, including readable inputs, buttons, navigation and overlays.
- Existing routine, timetable, prayer, goals, countdown, focus and AI features are retained.
- Service-worker cache version updated so installed web assets can refresh.

## OpenAI API setup
The app does not contain an OpenAI API key. Deploy `worker/index.js` as a Cloudflare Worker and store `OPENAI_API_KEY` as a Worker Secret. Configure the model to one available to your API project, set `APP_VERSION=3.2.0` and `ALLOWED_ORIGINS=capacitor://localhost,http://localhost,https://localhost`, then save the Worker HTTPS URL in app Settings. Never put the API key in the app source or APK. API usage is billed separately from ChatGPT subscriptions.

## Important limitations
- Focus mode allows ChatGPT and supported browsers while blocking other apps. Allowing a browser permits the entire browser, not only research websites.
- The Android AccessibilityService focus feature is optional and user-controlled; it is not tamper-proof.
- Existing app data is stored locally. Export a JSON backup before uninstalling or clearing app data.
- A native iOS release still requires macOS/Xcode, Apple signing and App Store/TestFlight distribution.
