# Daily Routine Tracker 3.1.0 — Graphite Studio + OpenAI Study Edition

A mobile-first daily planner and study timetable built with modular JavaScript, CSS and Capacitor. Existing local routines, prayer calculations, timetable entries, goals and JSON backups are preserved.

## Android build
1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Open GitHub Actions and run **Build Daily Routine Tracker APK**.
3. Download the `Daily-Routine-Tracker-APK` artifact and install the APK.

The supplied workflow builds an Android debug APK on Linux. Android requires the user to approve APK installation; an APK cannot silently replace an installed app. This is not a signed Play Store release.

## OpenAI API setup (required for cloud AI)
The app does not contain an OpenAI API key. Deploy the included Cloudflare Worker from `worker/`:

Phone-friendly Cloudflare Dashboard setup:
1. Open the Cloudflare dashboard in your phone browser and sign in.
2. Go to **Workers & Pages → Create → Worker** and create a Worker.
3. Open its code editor, replace the starter code with the complete contents of `worker/index.js`, then Deploy.
4. Open the Worker **Settings → Variables and Secrets**. Add `OPENAI_API_KEY` as a **Secret** and paste your OpenAI API key into that secret field. Never put it in `index.html`, `app.js`, GitHub source, or this chat.
5. Add these plain-text variables: `OPENAI_MODEL` = `gpt-6-astra`; `APP_VERSION` = `3.1.0`; `ALLOWED_ORIGINS` = `capacitor://localhost,http://localhost,https://localhost`. Save and deploy the changes.
6. Copy the Worker HTTPS URL. In the app, open Settings, paste the URL and save it.
7. Open the AI tab. Enable **Search the web** when you want sourced, current research.

You can also deploy from the `worker/` folder with Wrangler if you have a computer. Configure a Cloudflare rate-limiting rule for `/api/chat` and set API usage/budget limits in your OpenAI project before sharing the app.

The Worker uses the OpenAI Responses API and the built-in `web_search` tool when requested. API usage is billed separately by OpenAI. The default model is `gpt-6-astra` (flagship; higher cost than smaller models); change `OPENAI_MODEL` in Worker variables if your API account uses a different available model.

For production, configure Cloudflare rate limiting on `/api/chat` and set usage/budget limits in your OpenAI project. The API key is stored as a Worker secret, not in the APK.

## App updates
The app can check `/api/version` on the Worker and display a newer version when available. Configure `APP_VERSION`, `ANDROID_APK_URL`, and `IOS_APP_URL` in Worker variables after publishing a release. The APK download URL must be publicly reachable by the device. Android installation always requires user confirmation. iOS updates must be distributed through App Store or TestFlight; a website cannot silently install an IPA.

## iOS support
The UI and API layer are platform-neutral and Capacitor includes iOS support. This workflow currently produces an Android APK only. A real iPhone release requires a macOS/Xcode build, Apple signing and App Store/TestFlight distribution.

## Main upgrades in this edition
- Graphite Studio visual system: flat editorial layout, card-free activity rows, redesigned navigation, controls and settings theme.
- Modular `app.js`, `prayer.js`, `enhancements.js` and `styles.css` files.
- Card-free editorial layout with large typography and timeline-style sections.
- Secure OpenAI chat through a Cloudflare Worker; legacy Gemini/Claude keys from the previous local settings are cleared, and no OpenAI key is stored in client code.
- Optional Responses API web search with source links.
- Focus mode shortcuts for ChatGPT, in-app AI and web research.
- Large live countdown for the next exam and a custom achievement milestone.
- Scheduled reminders restricted to prayer/azan times only.
- Version check endpoint for Android/iOS update notices.
- Existing study timetable, prayer-time calculations, goals, local data and JSON backup retained.

## Important limitations
- Focus mode allows ChatGPT and supported browsers while blocking other apps. Allowing a browser permits the entire browser, not only research websites; website-level filtering is not included.
- The app's AccessibilityService focus feature is optional and user-controlled; it is not tamper-proof.
- Existing app data is stored locally. Export a JSON backup before uninstalling or clearing app data.
- OpenAI API billing is separate from ChatGPT subscriptions.
- A native iOS build still requires macOS/Xcode and Apple signing/distribution.
