package com.mydaily.tracker;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(AlarmPlugin.class);
    registerPlugin(FocusBlockingPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
